<?php
require_once ("db_connect.php");

$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$orgnum = $_POST['orgnum'];
if (!preg_match('/^\d{2}-\d{5}$/', $orgnum)) {
    echo "<script>alert('Invalid organization number format');</script>";
    exit;
}
$email = $_POST['email'];
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "<script>alert('Invalid email address');</script>";
    exit;
    
}
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

$stmt = $pdo->prepare("INSERT INTO users (org_num, fname, mname, lname, email, password) VALUES (:orgnum, :fname, :mname, :lname, :email, :password)");
$stmt->execute([
    ':orgnum' => $orgnum,
    ':fname' => $fname,
    ':mname' => $mname,
    ':lname' => $lname,
    ':email' => $email,
    ':password' => $password
]);
echo "<script>

alert('Registration successful!');
window.location.href = 'login.php';

</script>";
exit;
?>
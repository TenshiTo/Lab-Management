//Password and Confirm Password validation
        const passwordReg = document.getElementById("inputPassword");
        const confirmPassword = document.getElementById("inputPasswordConfirm");
        const confirmPasswordError = document.getElementById("confirmPasswordError");
        const formReg = document.getElementById("form");

        confirmPassword.addEventListener("input", function (){
            if (confirmPassword.value !== passwordReg.value) {
                confirmPasswordError.textContent = "Passwords do not match.";
            } else {
                confirmPasswordError.textContent = "";
            }
        });

        formReg.addEventListener("submit", function(event){
            if (confirmPassword.value !== passwordReg.value) {
                event.preventDefault();
                confirmPasswordError.textContent = "Passwords do not match.";
                alert("Please fix the errors in the form before submitting.");
            }
        });

        


<?php
session_start();
require_once "db_connect.php";
if (!isset($_SESSION['user_id']) || $_SESSION['roleId'] != 2) {
    $_SESSION = [];
    session_destroy(); 

    if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
    }
    header("Location: login.php");
    exit;
}

//recroding last activity time
$lastActStmt = $pdo->prepare("UPDATE users SET last_activity = NOW() WHERE user_id = :user_id");
$lastActStmt->execute(['user_id' => $_SESSION['user_id']]);

//updating inactive users
$updateStmt = $pdo->prepare("UPDATE users SET isActive = 0 WHERE isActive = 1 AND last_activity < NOW() - INTERVAL 1 YEAR");
$updateStmt->execute();

// Fetch counts for dashboard table (dean and mis not included)
$stmt = $pdo->prepare("SELECT u.*, r.role_name FROM users u JOIN roles r ON u.roleId = r.roleId WHERE u.roleId = :roleId AND u.isActive = 1");
$stmt->execute(['roleId' => 3]);

//Count users by role and total count
$stmtCount = $pdo->query("SELECT isActive, COUNT(*) as total FROM users WHERE roleId != 1 and roleId !=2 GROUP BY isActive");
$counts = $stmtCount->fetchAll(PDO::FETCH_KEY_PAIR);
$inactiveS = $counts[0] ?? 0;
$activeS = $counts[1] ?? 0;
$totalCount = $inactiveS + $activeS;

//For displaying user name
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE user_id = :user_id");
$stmtUser->execute(['user_id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

//data preparing for chart
$stmtChart = $pdo->query("SELECT DATE_FORMAT(`signup-at`, '%M %Y') AS label, COUNT(*) AS total FROM users GROUP BY YEAR(`signup-at`), MONTH(`signup-at`) ORDER BY YEAR(`signup-at`), MONTH(`signup-at`)");
$labels = [];
$values = [];

//data preparing for chart
while ($row = $stmtChart->fetch(PDO::FETCH_ASSOC)) {
    $labels[] = $row['label'];
    $values[] = $row['total'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $action = $_POST['action'];


    if ($action === 'deactivate') {
        $userId = $_POST['user_id'];
        $updateStatusStmt = $pdo->prepare("UPDATE users SET isActive = :isActive WHERE user_id = :user_id");
        $updateStatusStmt->execute(['isActive' => 0, 'user_id' => $userId]);
        header("Location: indexR2.php");
        exit;
    } elseif ($action === 'addtask') {
        $task = $_POST['task'];
        $description = $_POST['description'];
        $due = $_POST['due'];
        $insertTaskStmt = $pdo->prepare("INSERT INTO task (task, description, due) VALUES (:task, :description, :due_date)");
        $insertTaskStmt->execute(['task' => $task,'description' => $description,'due_date' => $due]);
        header("Location: indexR2.php");
        exit;
    }
    
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Lab Management - MIS</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="css/style.css">
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.php">Welcome!<br><?php echo htmlspecialchars($user['fname'], ENT_QUOTES, 'UTF-8'); ?></a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <hidden>ewan nawawala kasi ung space pag wala tong form HAHAHAHAH</hidden>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link disabled active" href="index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Addons</div>
                            <a class="nav-link" href="tablesMIS.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Inactive Users
                            </a>
                            <a class="nav-link" href="tasksR2.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Tasks
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        <?php echo $user['fname']. " ". $user['mname']. " ". $user['lname']; ?>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Head Count</li>
                        </ol>
                        <div class="row">
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body">Total</div>
                                    <div class="card-header"><h3><?php echo $totalCount; ?></h3></div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body">Active Student</div>
                                    <div class="card-header">
                                        <h3><?php echo $activeS; ?></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card bg-danger text-white mb-4">
                                    <div class="card-body">Inactive Students</div>
                                    <div class="card-header">
                                        <h3><?php echo $inactiveS; ?></h3>
                                    </div>
                                    <div class="card-footer">
                                        <a class="text-white small" href="tablesMIS.php">View Details</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-area me-1"></i>
                                        Area
                                    </div>
                                    <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-bar me-1"></i>
                                        Bar
                                    </div>
                                    <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
                                </div>
                            </div>
                        </div>

                       
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Active Users Table
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Organization Number</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Organization Number</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Status</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                    <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($row['org_num']) ?></td>
                                            <td><?= htmlspecialchars($row['fname'].' '.$row['mname'].' '.$row['lname']) ?></td>
                                            <td><?= htmlspecialchars($row['email']) ?></td>
                                            <td><?= htmlspecialchars($row['role_name']) ?></td>
                                            <td>
                                                <div  style="display:flex; justify-content:space-between; align-items:center; text-align:center;" >
                                                    <?= $row['isActive'] ? 'Active' : 'Inactive' ?>
                                                    <form method="post">
                                                        <input type="hidden" name="action" value="deactivate">
                                                        <input type="hidden" name="user_id" value="<?= $row['user_id'] ?>">
                                                        <button type="submit" class="btn btn-outline-danger btn-sm">Deactivate</button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                <!--end of the table--> </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2023</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script>
            window.chartLabels = <?= json_encode($labels) ?>;
            window.chartData = <?= json_encode($values) ?>;
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        

    </body>
</html>

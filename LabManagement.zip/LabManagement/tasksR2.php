<?php
session_start();
require_once "db_connect.php";
if (!isset($_SESSION['user_id']) || $_SESSION['roleId'] != 2) {
    $_SESSION = [];
    session_destroy(); 

    if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
    }
    header("Location: login.php");
    exit;
}

//recroding last activity time
$lastActStmt = $pdo->prepare("UPDATE users SET last_activity = NOW() WHERE user_id = :user_id");
$lastActStmt->execute(['user_id' => $_SESSION['user_id']]);

//updating inactive users
$updateStmt = $pdo->prepare("UPDATE users SET isActive = 0 WHERE isActive = 1 AND last_activity < NOW() - INTERVAL 1 YEAR");
$updateStmt->execute();

//Get tasks
$stmtTasks = $pdo->query("SELECT * FROM task ORDER BY due ASC");

//For displaying user name
$stmtUser = $pdo->prepare("SELECT * FROM users WHERE user_id = :user_id");
$stmtUser->execute(['user_id' => $_SESSION['user_id']]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

//Deleteing a task
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['action'] === 'deletetask') {

    $taskID = $_POST['task_id'];
    $deleteStmt = $pdo->prepare("DELETE FROM task WHERE id = :id");
    $deleteStmt->execute(['id' => $taskID]);
    header("Location: tasksR2.php");
    exit;

    } elseif ($_POST['action'] === 'addtask') {

        $task = $_POST['task'];
        $description = $_POST['description'];
        $due = $_POST['due'];
        $insertTaskStmt = $pdo->prepare("INSERT INTO task (task, description, due) VALUES (:task, :description, :due_date)");
        $insertTaskStmt->execute(['task' => $task,'description' => $description,'due_date' => $due]);
        header("Location: tasksR2.php");
        exit;

    }

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Tasks</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="css/style.css">
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.php">Welcome!<br><?php echo htmlspecialchars($user['fname'], ENT_QUOTES, 'UTF-8'); ?></a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <hidden>ewan nawawala kasi ung space pag wala tong form HAHAHAHAH</hidden>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="indexR2.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <div class="sb-sidenav-menu-heading">Addons</div>
                            <a class="nav-link" href="tablesMIS.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Inactive Users
                            </a>
                            <a class="nav-link disabled active" href="tasksR2.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Tasks
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        <?php echo htmlspecialchars($user['fname']. " " . $user["mname"] . " " . $user['lname'], ENT_QUOTES, 'UTF-8'); ?>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                    <h1 class="mt-4">Task and Activities</h1>
                    

                     <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                          New Task
                        </button><br><br>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                              <form method="post">
                                  <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Add New Task</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                  </div>

                                  <div class="modal-body">

                                    <!-- Task Name -->
                                    <div class="mb-3">
                                      <label class="form-label">Task</label>
                                      <input type="text" name="task" class="form-control" placeholder="Enter task title" required>
                                    </div>

                                    <!-- Description -->
                                    <div class="mb-3">
                                      <label class="form-label">Description</label>
                                      <textarea name="description" class="form-control" rows="3" placeholder="Task details" required></textarea>
                                    </div>

                                    <!-- Due Date -->
                                    <div class="mb-3">
                                      <label class="form-label">Due Date</label>
                                      <input type="date" name="due" class="form-control" required>
                                    </div>

                                  </div>
                                    <input type="hidden" name="action" value="addtask">
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Save Task</button>
                                  </div>
                                </form>
                            </div>
                          </div>
                        </div>

                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-clipboard-list me-1"></i>
                            List of Tasks
                        </div>
                        <div class="card-body">
                            <table id="datatablesSimple">
                                <thead>
                                    <tr>
                                        <th>Task</th>
                                        <th>Description</th>
                                        <th>Due Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>Task</th>
                                        <th>Description</th>
                                        <th>Due Date</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php while ($tasks = $stmtTasks->fetch(PDO::FETCH_ASSOC)): ?>
                                    <tr>
                                        <td><?= $tasks['task'] ?></td>
                                        <td><?= $tasks['description'] ?></td>
                                        <td><?= date("F j, Y", strtotime($tasks['due'])) ?></td>
                                        <td>
                                            <form method="post" onsubmit="return confirm('Are you sure you want to delete this task?');">
                                                <input type="hidden" name="task_id" value="<?= $tasks['id'] ?>">
                                                <input type="hidden" name="action" value="deletetask">
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2023</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>





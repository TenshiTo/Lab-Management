-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2026 at 08:29 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `labman`
--

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `roleId` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `description` varchar(150) NOT NULL,
  `isActive` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`roleId`, `role_name`, `description`, `isActive`) VALUES
(1, 'Dean', 'Wala pa', 0),
(2, 'MIS', 'Wala pa din', 0),
(3, 'Student', 'Wala pay', 0);

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `task` varchar(150) NOT NULL,
  `description` varchar(150) NOT NULL,
  `due` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `task`, `description`, `due`) VALUES
(2, 'Sample', 'Sample', '2026-01-17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `org_num` varchar(15) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password` varchar(265) NOT NULL,
  `roleId` int(5) NOT NULL DEFAULT 3,
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `signup-at` varchar(50) NOT NULL DEFAULT current_timestamp(),
  `last_activity` varchar(50) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `org_num`, `fname`, `mname`, `lname`, `email`, `password`, `roleId`, `isActive`, `signup-at`, `last_activity`) VALUES
(2, '25-00121', 'Angelo', 'Diose', 'Male', 'angelomale87@gmail.com', '$2y$10$2Er0qa8TsoUE6ufW2fAB.e3E3GvLGV/TlOzvJ5/XK0/ckr7opnVai', 2, 1, '2026-01-14 00:09:38', '2026-01-16 03:10:27'),
(3, '25-00198', 'Alessandro', 'Tacalan', 'Feria', 'alessandroferia263@gmail.com', '$2y$10$3NTsTl1Vg7db4Lfq.lMK0eWOPNx0EXvkePQFJqe8U44mreaYHcZoO', 2, 1, '2026-01-16 00:09:38', '2026-01-14 03:31:18'),
(4, '25-12345', 'Harold', 'R', 'Lucero', 'haroldlucero@gmail.com', '$2y$10$s2csBfXRSdU70ry4r5pXdewqSy2TZShPrYcWDF0oq1NsFeGY13nrS', 1, 1, '2026-01-01 00:09:38', '2026-01-16 03:25:25'),
(5, '25-00179', 'Mariel', 'Du', 'Leoncio', 'marielcsta01@gmail.com', '$2y$10$X.lCWB3zvuuDddwX4JiTT.pmvn6/ysIZw3zNQDBsyNZzqzAlF60Sa', 2, 1, '2026-01-17 00:09:38', '2026-01-14 02:18:00'),
(6, '25-67676', 'Maria', 'Angela', 'Garcia', 'mariaangela@gmail.com', '$2y$10$EAS.96Bzn6J7wGDE38B3UeqMlbnWXvHmwCSAxtTYsQ8SX776q4nPG', 3, 0, '2026-01-14 00:10:50', '2026-01-14 03:31:33'),
(7, '25-00001', 'Juan', 'M', 'Dela Cruz', 'juan1@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-01-10 09:00:00', '2026-01-10 10:00:00'),
(8, '25-00002', 'Maria', 'L', 'Santos', 'maria2@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-02-12 10:15:00', '2026-01-12 08:30:00'),
(9, '25-00003', 'Pedro', 'A', 'Reyes', 'pedro3@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2024-03-01 08:45:00', '2026-01-05 12:00:00'),
(10, '25-00004', 'Ana', 'C', 'Lopez', 'ana4@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2023-12-20 14:20:00', '2026-01-14 03:31:34'),
(11, '25-00005', 'Mark', 'J', 'Villanueva', 'mark5@test.com', '$2y$10$abcdefghijklmnopqrstuv', 1, 1, '2024-04-10 11:00:00', '2026-01-14 02:40:00'),
(12, '25-00006', 'Liza', 'P', 'Garcia', 'liza6@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-05-05 09:30:00', '2026-01-13 18:00:00'),
(13, '25-00007', 'Ryan', 'T', 'Mendoza', 'ryan7@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2023-10-15 15:45:00', '2026-01-14 03:31:35'),
(14, '25-00008', 'Kim', 'R', 'Flores', 'kim8@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2024-06-01 08:10:00', '2026-01-14 01:00:00'),
(15, '25-00009', 'Noel', 'B', 'Torres', 'noel9@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-06-20 13:30:00', '2026-01-14 02:00:00'),
(16, '25-00010', 'Paolo', 'E', 'Cruz', 'paolo10@test.com', '$2y$10$abcdefghijklmnopqrstuv', 1, 1, '2024-07-01 07:50:00', '2026-01-14 02:30:00'),
(17, '25-00011', 'Joy', 'M', 'Ramos', 'joy11@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-07-10 09:10:00', '2026-01-10 14:00:00'),
(18, '25-00012', 'Chris', 'D', 'Aquino', 'chris12@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2023-08-05 16:40:00', '2026-01-14 03:35:32'),
(19, '25-00013', 'Ella', 'S', 'Lim', 'ella13@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-08-01 10:00:00', '2026-01-14 02:18:00'),
(20, '25-00014', 'Ben', 'K', 'Uy', 'ben14@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-08-15 11:25:00', '2026-01-14 02:18:00'),
(21, '25-00015', 'Tina', 'G', 'Chua', 'tina15@test.com', '$2y$10$abcdefghijklmnopqrstuv', 1, 1, '2024-09-01 09:00:00', '2026-01-13 23:00:00'),
(23, '25-00017', 'Faith', 'A', 'Castro', 'faith17@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-09-20 14:00:00', '2026-01-14 02:18:00'),
(24, '25-00018', 'Ian', 'C', 'Navarro', 'ian18@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2024-10-01 08:45:00', '2026-01-14 02:18:00'),
(25, '25-00019', 'Jade', 'N', 'Morales', 'jade19@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-10-10 09:50:00', '2026-01-14 02:18:00'),
(26, '25-00020', 'Kyle', 'L', 'Pascual', 'kyle20@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-10-20 10:10:00', '2026-01-14 02:18:00'),
(27, '25-00021', 'Alex', 'R', 'Bautista', 'alex21@test.com', '$2y$10$abcdefghijklmnopqrstuv', 1, 1, '2024-11-01 08:00:00', '2026-01-14 02:18:00'),
(28, '25-00022', 'Mia', 'F', 'Delos Reyes', 'mia22@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-11-05 09:30:00', '2026-01-14 02:18:00'),
(29, '25-00023', 'Sean', 'V', 'Ortiz', 'sean23@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2024-11-10 10:00:00', '2026-01-14 02:18:00'),
(30, '25-00024', 'Nina', 'J', 'Gomez', 'nina24@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 0, '2023-07-01 14:00:00', '2024-01-05 08:00:00'),
(31, '25-00025', 'Owen', 'T', 'Salazar', 'owen25@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-12-01 11:00:00', '2026-01-14 02:18:00'),
(32, '25-00026', 'Zoe', 'M', 'Aguilar', 'zoe26@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-12-05 09:00:00', '2026-01-14 02:18:00'),
(33, '25-00027', 'Paul', 'R', 'Estrada', 'paul27@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2024-12-10 08:30:00', '2026-01-14 02:18:00'),
(34, '25-00028', 'Ivy', 'C', 'Domingo', 'ivy28@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-12-15 10:20:00', '2026-01-14 02:18:00'),
(35, '25-00029', 'Mark', 'E', 'Padilla', 'mark29@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2024-12-20 11:40:00', '2026-01-14 02:18:00'),
(36, '25-00030', 'Liam', 'P', 'Rosales', 'liam30@test.com', '$2y$10$abcdefghijklmnopqrstuv', 1, 1, '2024-12-25 12:00:00', '2026-01-14 02:18:00'),
(37, '25-00031', 'Aaron', 'J', 'Cortez', 'aaron31@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-01-01 09:00:00', '2026-01-14 02:18:00'),
(38, '25-00032', 'Bella', 'M', 'Rivera', 'bella32@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-01-03 10:30:00', '2026-01-14 02:18:00'),
(39, '25-00033', 'Carl', 'D', 'Moreno', 'carl33@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2025-01-05 08:15:00', '2026-01-14 02:18:00'),
(40, '25-00034', 'Diane', 'S', 'Alvarez', 'diane34@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 0, '2024-01-10 13:40:00', '2024-01-15 09:00:00'),
(41, '25-00035', 'Evan', 'R', 'Silva', 'evan35@test.com', '$2y$10$abcdefghijklmnopqrstuv', 1, 1, '2025-01-10 11:00:00', '2026-01-14 02:18:00'),
(42, '25-00036', 'Faye', 'L', 'Cabrera', 'faye36@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-01-15 09:20:00', '2026-01-14 02:18:00'),
(43, '25-00037', 'Gio', 'A', 'Roxas', 'gio37@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-01-18 10:10:00', '2026-01-14 02:18:00'),
(44, '25-00038', 'Hana', 'C', 'Soriano', 'hana38@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2025-01-20 08:50:00', '2026-01-14 02:18:00'),
(45, '25-00039', 'Ivan', 'M', 'Delgado', 'ivan39@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-01-25 09:00:00', '2026-01-14 02:18:00'),
(46, '25-00040', 'Jill', 'P', 'Valdez', 'jill40@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-01-30 10:30:00', '2026-01-14 02:18:00'),
(47, '25-00041', 'Kevin', 'B', 'Reyes', 'kevin41@test.com', '$2y$10$abcdefghijklmnopqrstuv', 1, 1, '2025-02-01 08:00:00', '2026-01-14 02:18:00'),
(48, '25-00042', 'Lara', 'D', 'Cruz', 'lara42@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-02-03 09:15:00', '2026-01-14 02:18:00'),
(49, '25-00043', 'Miles', 'E', 'Tan', 'miles43@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2025-02-05 10:45:00', '2026-01-14 02:18:00'),
(50, '25-00044', 'Nora', 'S', 'Lim', 'nora44@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 0, '2024-02-01 14:00:00', '2024-02-05 09:00:00'),
(51, '25-00045', 'Omar', 'T', 'Ferrer', 'omar45@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-02-10 08:30:00', '2026-01-14 02:18:00'),
(52, '25-00046', 'Pia', 'M', 'Chavez', 'pia46@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-02-15 09:00:00', '2026-01-14 02:18:00'),
(53, '25-00047', 'Quinn', 'J', 'Yu', 'quinn47@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2025-02-18 10:10:00', '2026-01-14 02:18:00'),
(54, '25-00048', 'Ralph', 'K', 'Co', 'ralph48@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-02-20 11:20:00', '2026-01-14 02:18:00'),
(55, '25-00049', 'Sophie', 'A', 'Gonzales', 'sophie49@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-02-25 09:45:00', '2026-01-14 02:18:00'),
(56, '25-00050', 'Theo', 'R', 'Bernardo', 'theo50@test.com', '$2y$10$abcdefghijklmnopqrstuv', 1, 1, '2025-02-28 08:00:00', '2026-01-14 02:18:00'),
(57, '25-00051', 'Uma', 'C', 'Naval', 'uma51@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-03-01 09:00:00', '2026-01-14 02:18:00'),
(58, '25-00052', 'Vince', 'E', 'Pineda', 'vince52@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2025-03-03 10:30:00', '2026-01-14 02:18:00'),
(59, '25-00053', 'Will', 'J', 'Sarmiento', 'will53@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-03-05 11:00:00', '2026-01-14 02:18:00'),
(60, '25-00054', 'Xena', 'L', 'Abad', 'xena54@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 0, '2024-03-01 13:00:00', '2024-03-05 08:00:00'),
(61, '25-00055', 'Yuri', 'M', 'Basilio', 'yuri55@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-03-10 09:30:00', '2026-01-14 02:18:00'),
(62, '25-00056', 'Zack', 'T', 'Ramos', 'zack56@test.com', '$2y$10$abcdefghijklmnopqrstuv', 1, 1, '2025-03-12 08:00:00', '2026-01-14 02:18:00'),
(63, '25-00057', 'Aly', 'R', 'David', 'aly57@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-03-15 09:00:00', '2026-01-14 02:18:00'),
(64, '25-00058', 'Brent', 'C', 'Ilustre', 'brent58@test.com', '$2y$10$abcdefghijklmnopqrstuv', 2, 1, '2025-03-18 10:00:00', '2026-01-14 02:18:00'),
(65, '25-00059', 'Celine', 'A', 'Flores', 'celine59@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-03-20 11:30:00', '2026-01-14 02:18:00'),
(66, '25-00060', 'Drew', 'B', 'Espino', 'drew60@test.com', '$2y$10$abcdefghijklmnopqrstuv', 3, 1, '2025-03-25 08:45:00', '2026-01-14 02:18:00'),
(67, '25-00122', 'Maricel', 'Soriano', 'Ochoa', 'oriongates@gmail.com', '$2y$10$upT3ivS.3sYvpuSUPxKQdektkvclBspm.ujWLVT/9SUiNf5zUh656', 3, 1, '2026-01-16 01:15:08', '2026-01-16 03:10:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`roleId`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `roleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
